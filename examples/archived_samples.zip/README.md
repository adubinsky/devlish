# Devlish Examples

Last updated: 2026-03-23
Status: Current course entry point.

This directory is the teaching surface for Devlish.

The main table of contents is:
- [examples/DEVLISH_COURSE.md](/Users/admin/code/devlish/examples/DEVLISH_COURSE.md)

That course map consolidates the runnable examples into a logical learning
path:
- Module 0: syntax warmup
- Module 1: workflow fundamentals
- Module 2: class-style Devlish
- Module 3: domain workflows
- Module 4: specialized calculators and rules
- Module 5: end-to-end system example

## Current Lesson Packs

- `simple/` - Module 0 warmup and syntax drills
- `tutorial/` - Module 1 workflow fundamentals
- `class_style/` - Module 2 class-style lessons
- `business/` - Module 3 domain workflow lessons
- `accounting/`, `hr/`, `retirement/` - Module 4 specialized rule packs
- `medication-invoice-verifier/` - Module 5 system example
- `legacy/` - archived pre-course material only

## Quick Start

```bash
./bin/devlish run examples/tutorial/01_load_and_check.dvl --debug
./bin/devlish test examples/tutorial/tests/tutorial_curriculum.dvt
./bin/devlish run examples/class_style/01_payroll_calculator.dvl --method calculate_wages --args '[40,25]'
./bin/devlish trace examples/class_style/04_helper_invocation.dvl --method review_invoice --args '[12000]'
```
