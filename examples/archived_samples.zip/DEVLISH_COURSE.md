# Devlish Course

Last updated: 2026-03-23
Status: Current comprehensive learning path for runnable Devlish examples.

This file is the table of contents for learning Devlish as a language.

The goal is to make the `examples/` tree read like a course, not a grab bag.
Every runnable example should fit somewhere in the progression below.

## How To Use This Course

Suggested rhythm:

1. Read the lesson section for one module.
2. Run the example files in order.
3. Use `devlish trace` when you want to inspect AST, IR, or class IR.
4. Use `devlish test` to validate behavior in Devlish terms.
5. Move to the next module once the current one feels natural.

Core commands:

```bash
./bin/devlish run examples/tutorial/01_load_and_check.dvl --debug
./bin/devlish trace examples/tutorial/03_branch_and_route.dvl
./bin/devlish test examples/tutorial/tests/tutorial_curriculum.dvt
./bin/devlish run examples/class_style/01_payroll_calculator.dvl --method calculate_wages --args '[40,25]'
./bin/devlish package examples/tutorial/03_branch_and_route.dvl --target ruby
```

## Course TOC

### Module 0: Core Syntax Warmup

Purpose:
- learn the smallest runnable shapes
- see direct examples of checks, extraction, branching, routing, and binding

Lessons:
- [examples/simple/01_load_and_check.dvl](/Users/admin/code/devlish/examples/simple/01_load_and_check.dvl)
- [examples/simple/02_extract_and_validate.dvl](/Users/admin/code/devlish/examples/simple/02_extract_and_validate.dvl)
- [examples/simple/03_conditionals.dvl](/Users/admin/code/devlish/examples/simple/03_conditionals.dvl)
- [examples/simple/04_route_and_log.dvl](/Users/admin/code/devlish/examples/simple/04_route_and_log.dvl)
- [examples/simple/05_bindings_aliases.dvl](/Users/admin/code/devlish/examples/simple/05_bindings_aliases.dvl)
- [examples/simple/06_nickname_collision.dvl](/Users/admin/code/devlish/examples/simple/06_nickname_collision.dvl)
- [examples/simple/comprehensive.dvl](/Users/admin/code/devlish/examples/simple/comprehensive.dvl)
- [examples/simple/defined_terms.dvl](/Users/admin/code/devlish/examples/simple/defined_terms.dvl)
- [examples/simple/natural_contract.dvl](/Users/admin/code/devlish/examples/simple/natural_contract.dvl)
- [examples/simple/reserved_words_demo.dvl](/Users/admin/code/devlish/examples/simple/reserved_words_demo.dvl)

Reference:
- [examples/simple/README.md](/Users/admin/code/devlish/examples/simple/README.md)

### Module 1: Workflow Fundamentals

Purpose:
- learn Devlish as a document-driven workflow language
- understand the current Devlish 2.0 workflow subset

Lessons:
- [examples/tutorial/01_load_and_check.dvl](/Users/admin/code/devlish/examples/tutorial/01_load_and_check.dvl)
- [examples/tutorial/02_extract_and_validate.dvl](/Users/admin/code/devlish/examples/tutorial/02_extract_and_validate.dvl)
- [examples/tutorial/03_branch_and_route.dvl](/Users/admin/code/devlish/examples/tutorial/03_branch_and_route.dvl)
- [examples/tutorial/04_send_email_output.dvl](/Users/admin/code/devlish/examples/tutorial/04_send_email_output.dvl)
- [examples/tutorial/05_send_message_output.dvl](/Users/admin/code/devlish/examples/tutorial/05_send_message_output.dvl)
- [examples/tutorial/06_bind_a_name.dvl](/Users/admin/code/devlish/examples/tutorial/06_bind_a_name.dvl)

Tests:
- [examples/tutorial/tests/tutorial_curriculum.dvt](/Users/admin/code/devlish/examples/tutorial/tests/tutorial_curriculum.dvt)

Reference:
- [examples/tutorial/README.md](/Users/admin/code/devlish/examples/tutorial/README.md)

### Module 2: Class-Style Devlish

Purpose:
- learn modules, classes, methods, parameters, private helpers, and return values
- see the current Devlish 2.0 class IR pipeline in action

Lessons:
- [examples/class_style/01_payroll_calculator.dvl](/Users/admin/code/devlish/examples/class_style/01_payroll_calculator.dvl)
- [examples/class_style/02_participant_classifier.dvl](/Users/admin/code/devlish/examples/class_style/02_participant_classifier.dvl)
- [examples/class_style/03_private_helper.dvl](/Users/admin/code/devlish/examples/class_style/03_private_helper.dvl)
- [examples/class_style/04_helper_invocation.dvl](/Users/admin/code/devlish/examples/class_style/04_helper_invocation.dvl)

Tests:
- [examples/class_style/tests/class_curriculum.dvt](/Users/admin/code/devlish/examples/class_style/tests/class_curriculum.dvt)

Reference:
- [examples/class_style/README.md](/Users/admin/code/devlish/examples/class_style/README.md)

### Module 3: Domain Workflows

Purpose:
- see how the same core syntax expresses real business rules
- move from toy inputs to structured document review problems

Lessons:
- [examples/business/finance/expense_report_review.dvl](/Users/admin/code/devlish/examples/business/finance/expense_report_review.dvl)
- [examples/business/hr/onboarding_packet_check.dvl](/Users/admin/code/devlish/examples/business/hr/onboarding_packet_check.dvl)
- [examples/business/healthcare/claim_intake_triage.dvl](/Users/admin/code/devlish/examples/business/healthcare/claim_intake_triage.dvl)
- [examples/business/legal/vendor_contract_screen.dvl](/Users/admin/code/devlish/examples/business/legal/vendor_contract_screen.dvl)
- [examples/business/operations/incident_priority_sort.dvl](/Users/admin/code/devlish/examples/business/operations/incident_priority_sort.dvl)
- [examples/business/retail/return_request_triage.dvl](/Users/admin/code/devlish/examples/business/retail/return_request_triage.dvl)
- [examples/business/testing/star_browser_verification_runbook.dvl](/Users/admin/code/devlish/examples/business/testing/star_browser_verification_runbook.dvl)

Reference:
- [examples/business/README.md](/Users/admin/code/devlish/examples/business/README.md)

### Module 4: Specialized Calculators And Rule Packs

Purpose:
- see focused vertical examples with stronger numeric and rules-heavy flavor

Lessons:
- [examples/accounting/contract_validator.dvl](/Users/admin/code/devlish/examples/accounting/contract_validator.dvl)
- [examples/accounting/depreciation_calculator.dvl](/Users/admin/code/devlish/examples/accounting/depreciation_calculator.dvl)
- [examples/accounting/futa_calculator.dvl](/Users/admin/code/devlish/examples/accounting/futa_calculator.dvl)
- [examples/accounting/rental_depreciation.dvl](/Users/admin/code/devlish/examples/accounting/rental_depreciation.dvl)
- [examples/hr/payroll_calculator.dvl](/Users/admin/code/devlish/examples/hr/payroll_calculator.dvl)
- [examples/retirement/contribution_limits.dvl](/Users/admin/code/devlish/examples/retirement/contribution_limits.dvl)

Reference:
- [examples/accounting/README.md](/Users/admin/code/devlish/examples/accounting/README.md)
- [examples/hr/README.md](/Users/admin/code/devlish/examples/hr/README.md)
- [examples/retirement/README.md](/Users/admin/code/devlish/examples/retirement/README.md)

### Module 5: End-To-End System Example

Purpose:
- see Devlish embedded inside a larger application/runtime shape
- understand how language files, definitions, scripts, and gateway pieces fit together

Project:
- [examples/medication-invoice-verifier/README.md](/Users/admin/code/devlish/examples/medication-invoice-verifier/README.md)

### Archive

Archived historical examples live in:
- [examples/legacy/README.md](/Users/admin/code/devlish/examples/legacy/README.md)

They are reference material, not current curriculum.

## Recommended Learning Order

1. Module 0 for quick language shapes.
2. Module 1 for the workflow model.
3. Module 2 for class-style Devlish.
4. Module 3 for realistic document-driven programs.
5. Module 4 for rules-heavy and numeric examples.
6. Module 5 for system integration context.

## Testing Track

Use these alongside the course:
- [examples/tutorial/tests/tutorial_curriculum.dvt](/Users/admin/code/devlish/examples/tutorial/tests/tutorial_curriculum.dvt)
- [examples/class_style/tests/class_curriculum.dvt](/Users/admin/code/devlish/examples/class_style/tests/class_curriculum.dvt)

These are the closest thing to executable lesson checks right now.
